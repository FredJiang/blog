package com.fred.model.po.mysql;

import lombok.Getter;
import lombok.Setter;

public class UserDomain {
  @Getter @Setter String username;
  @Getter @Setter String password;
}
